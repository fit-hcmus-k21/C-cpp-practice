#include <iostream>
using namespace std;

int main()
{
    cout<<"Xin chao tat ca cac ban..."<<endl;
    cout<<"Day la tap tin mau ahihi :v"<<endl;
    cout<<"Tap tin den day la ket thuc, bye bye ahaha =))"<<endl;
    return 225;
}